%% Modelling and Control of Manipulator assignment 3 - Exercise 1: Jacobian matrix
addpath('include')
% The same model of assignment 2
geom_model = BuildTree();
numberOfLinks = size(geom_model,3); % number of manipulator's links.
linkType = zeros(numberOfLinks,1); % specify two possible link type: Rotational, Prismatic.
bTi0 = zeros(4,4,numberOfLinks);% Trasformation matrix i-th link w.r.t. base
bTi1 = zeros(4,4,numberOfLinks);% Trasformation matrix i-th link w.r.t. base
bTi2 = zeros(4,4,numberOfLinks);% Trasformation matrix i-th link w.r.t. base
bTi3 = zeros(4,4,numberOfLinks);% Trasformation matrix i-th link w.r.t. base
bTi4 = zeros(4,4,numberOfLinks);% Trasformation matrix i-th link w.r.t. base
 
% Initial joint configuration 
q0 = [1.3,1.3,1.3,1.3,1.3,1.3,1.3];
q1 = [1.8,1.8,1.8,1.8,1.8,1.8,1.8];
q2 = [0.3, 1.4, 0.1, 2.0, 0, 1.3, 0];
q3 = [0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.];
q4 = [1, 1, 1, 1, 1, 1, 1];
%% Compute direct geometry

% Compute the transformation w.r.t. the base
biTei0 = GetDirectGeometry(q0, geom_model, linkType, numberOfLinks);
biTei1 = GetDirectGeometry(q1, geom_model, linkType, numberOfLinks);
biTei2 = GetDirectGeometry(q2, geom_model, linkType, numberOfLinks);
biTei3 = GetDirectGeometry(q3, geom_model, linkType, numberOfLinks);
biTei4 = GetDirectGeometry(q4, geom_model, linkType, numberOfLinks);

for i =1:numberOfLinks
    % per ogni frame prendo la relativa trasformazione rispetto alla
    % base
    bTi0(:,:,i)= GetTransformationWrtBase(biTei0, i);
    bTi1(:,:,i)= GetTransformationWrtBase(biTei1, i);
    bTi2(:,:,i)= GetTransformationWrtBase(biTei2, i);
    bTi3(:,:,i)= GetTransformationWrtBase(biTei3, i);
    bTi4(:,:,i)= GetTransformationWrtBase(biTei4, i);
end


% Computing end effector jacobian 
J0 = GetJacobian(biTei0, bTi0, linkType);
J1 = GetJacobian(biTei1, bTi1, linkType);
J2 = GetJacobian(biTei2, bTi2, linkType);
J3 = GetJacobian(biTei3, bTi3, linkType);
J4 = GetJacobian(biTei4, bTi4, linkType);



