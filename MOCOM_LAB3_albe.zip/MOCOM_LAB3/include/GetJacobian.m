function J = GetJacobian(biTei, bTe, jointType)
%% GetJacobian function
% Function returning the end effector jacobian for a manipulator which current
% configuration is described by bTei.
%
% Inputs:
% - biTei: vector of matrices containing the transformation matrices from
% joint i-1 to joint i for the current configuration.
% - bTe: current transformation matrix from base to the end effector.
% - jointType: vector identifying the joint type, 0 for revolute, 1 for
% prismatic
%
numLinks=length(jointType);
J=zeros(6,numLinks);
Ja=zeros(3,numLinks);
Jl=zeros(3,numLinks);
ire=zeros(3,numLinks);

for i=1:numLinks
    ire(:,i)=bTe(1:3,4,7)-bTe(1:3,4,i);
end
%Angular Jacobian
for i=1:numLinks
    %Revolute joint
    if jointType(i)==0
        Ja(1:3,i)=bTe(1:3,3,i);
    %Prismatic joint
    elseif jointType(i)==1
        Ja(1:3,i)=[0; 0; 0];
    end
end
%Linear Jacobian
for i=1:length(jointType)
    %Prismatic joint
    if jointType(i)==1
        Jl(:,i)=bTe(1:3,3,i);
    %Revolute joint
    elseif jointType(i)==0
        Jl(:,i)=cross(bTe(1:3,3,i),ire(:,i));
    end
end    



% Output:
% - J: end-effector jacobian matrix 
J=[Ja;Jl];

end