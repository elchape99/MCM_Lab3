function [theta,v] = ComputeInverseAngleAxis(R)
%EULER REPRESENTATION: Given a tensor rotation matrices this function
% should output the equivalent angle-axis representation values,
% respectively 'theta' (angle), 'v' (axis) 
% SUGGESTED FUNCTIONS
    % size()
    % eye()
    % eig()
    % find()
    % abs()
    % det()
    % NB: Enter a square, 3x3 proper-orthogonal matrix to calculate its angle
    % and axis of rotation. Error messages must be displayed if the matrix
    % does not satisfy the rotation matrix criteria.
    
    tol = 1e-4; %define tollerance
    % Check matrix R to see if its size is 3x3
    if size(R)==size(eye(3))
        % Check matrix R to see if it is orthogonal
        if  abs((R*R')-eye(3))<=tol
            % Check matrix R to see if it is proper: det(R) = 1
            if det(R)-1<tol
                % Compute the angle of rotation
                theta=acos((trace(R)-1)/2) ;
                % Calculate eigenvalues and eigenvectors of R
                % Compute the angle of rotation
                theta = acos((trace(R)-1)/2);
                
                % Compute the sin(theta)*V with vex
                tmp = (R - transpose(R))/2;
                vex = [tmp(3,2);tmp(1,3);tmp(2,1)];

                % compute v
                v = vex / sin(theta);
                      
            else
              err('DETERMINANT OF THE INPUT MATRIX IS NOT 1')
            end
        else
             err('NOT ORTHOGONAL INPUT MATRIX')
        end
    else
       err('WRONG SIZE OF THE INPUT MATRIX')
    end
end

